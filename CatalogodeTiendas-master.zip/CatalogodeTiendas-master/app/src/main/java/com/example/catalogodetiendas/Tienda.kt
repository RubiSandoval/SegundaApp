package com.example.catalogodetiendas

import java.util.UUID

data class Tienda(
    val id: UUID,
    val nombre:String,
    val telefono:String
)
